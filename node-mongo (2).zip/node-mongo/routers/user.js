var express = require('express');
const json2csv = require('json2csv').parse;
var User = require('../models/user');
var mongoose = require('mongoose');

var request = require("request");
var userRouter = express.Router();

userRouter
  .route('/users')
  .post(function (request, response) {

    var item = new User(request.body);

    item.save();

    response.status(201).send(item);
  })
  .get(function (request, response) {

    User.find(function (error, users) {

      if (error) {
        response.status(500).send(error);
        return;
      }

      console.log(users);

      response.json(users);
    });
  });


userRouter
  .route('/users/:userId')
  .get(function (request, response) {

    var userId = request.params.userId;

    User.findOne({ id: userId }, function (error, task) {

      if (error) {
        response.status(500).send(error);
        return;
      }

      console.log(task);

      response.json(task);

    });
  })
  .put(function (request, response) {

    var userId = request.params.userId;

    User.findOne({ id: userId }, function (error, task) {

      if (error) {
        response.status(500).send(error);
        return;
      }

      if (task) {
        task.name = request.body.name;
        task.email = request.body.email;
        task.gender = request.body.gender;
        task.status = request.body.status;
        task.updatedAt = new Date();
        
        task.save();

        response.json({message:"task data updated successfully"});
        return;
      }

      response.status(404).json({
        message: 'User with id ' + userId + ' was not found.'
      });
    });
  })

  .delete(function (request, response) {

    var userId = request.params.userId;

    User.findOne({ id: userId }, function (error, task) {
      
      if (error) {
        response.status(500).send(error);
        return;
      }

      if (task) {
        task.remove(function (error) {

          if (error) {
            response.status(500).send(error);
            return;
          }

          response.status(200).json({
            'message': 'User with id ' + userId + ' was removed.'
          });
        });
      } else {
        response.status(404).json({
          message: 'User with id ' + userId + ' was not found.'
        });
      }
    });
  });

module.exports = userRouter;